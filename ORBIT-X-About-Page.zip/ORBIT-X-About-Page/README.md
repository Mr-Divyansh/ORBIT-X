# ORBIT-X About Page Starter

Standalone responsive About page with separate HTML, CSS, and JavaScript.

- `index.html` — page content and layout
- `style.css` — theme, responsive layout, visual effects and animations
- `script.js` — scroll reveal and subtle pointer interaction

Open `index.html` in a browser to preview. Google Fonts need internet access; system fallbacks are included.

## Add your existing artwork
This starter deliberately uses labelled placeholders so you can place your own character and gadget assets. Search `COPILOT SPACE` in `index.html` for areas to customize.

Replace a placeholder with an image using the exact existing path, for example:
`<img class="your-image-class" src="assets/abhay.png" alt="Abhay holding his magical lantern">`

Do not assume extensions: inspect your real asset filenames. For transparent PNGs, use `object-fit: contain`.

Character gadget details:
- **Abhay's Ghostlight Lantern:** detects/reveals hidden ghosts and illuminates shadowy paths.
- **Divyansh's Dreamweaver Wand:** purifies restless ghosts and helps guide children safely out of frightening dreams.

The “Explore the Full Story” button currently points to `#duo` as a working fallback. Change it to the actual full-story route when you have one.
